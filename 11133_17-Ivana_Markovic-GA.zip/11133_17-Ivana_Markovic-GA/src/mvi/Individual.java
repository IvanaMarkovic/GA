package mvi;

import java.util.Random;

public class Individual {
    public static final int chromosomeLength=11;
    public int[] chromosome_X; //binarni kod broja slucajno izabranog u intervalu [Gd,Gg]
    public int[] chromosome_Y;
    public int bdX;
    public int bdY;
    public static final int Ggx= 3;
    public static final int Gdx= -3;
    public static final int Ggy = 4;
    public static final int Gdy= -4;
    public double realChromosomeX;
    public double realChromosomeY;
    public double qi;
    public double pi; //vjerovatnoca izbora jedinke

    double ffx;
    double fx;

    public Individual()
    {
        this.chromosome_X=new int[chromosomeLength];
        this.chromosome_Y=new int[chromosomeLength];

        for(int i=0;i<chromosomeLength;i++)
        {
            chromosome_X[i]=new Random().nextInt(2);
            chromosome_Y[i]=new Random().nextInt(2);
        }

        this.realChromosomeX=getDoubleChromosomeX();
        this.realChromosomeY=getDoubleChromosomeY();
    }


    //funkcija koja od binarne reprezentacije hromozoma daje broj

    public double getDoubleChromosomeX()
    {
        int bd=0;

        for(int i=0;i<chromosomeLength;i++)
        {
            if(chromosome_X[i]>0)
                bd+=Math.pow(2, i);
        }

        return (double)Gdx+(Ggx -Gdx) * bd / (Math.pow(2, chromosomeLength)-1);
    }

    public double getDoubleChromosomeY()
    {
        int bd=0;

        for(int i=0;i<chromosomeLength;i++)
        {
            if(chromosome_Y[i]>0)
                bd+=Math.pow(2, i);
        }

        return (double)Gdy+(Ggy -Gdy) * bd / (Math.pow(2, chromosomeLength)-1);
    }

    public double getFunctionValue()
    {
        fx = (3 * Math.pow((1 - realChromosomeX), 2) * Math.pow(Math.E, (-1) * (Math.pow(realChromosomeX, 2) + Math.pow(realChromosomeY + 1, 2))) -
                7 * (realChromosomeX / 5 - Math.pow(realChromosomeX, 3) - Math.pow(realChromosomeY, 5)) * Math.pow(Math.E, (-1) * (Math.pow(realChromosomeX, 2) + Math.pow(realChromosomeY, 2))) -
                (1 / 3) * Math.pow(Math.E, (-1) * (Math.pow(realChromosomeX + 2, 2) + Math.pow(realChromosomeY, 2))));

        return fx;
    }

    public double getMaxValue() {
        fx = 3 * Math.pow(Math.E, (-1) * Math.pow((realChromosomeY + 1), 2)) + 7 * Math.pow(realChromosomeY, 5) * Math.pow(Math.E, (-1) * Math.pow(realChromosomeY, 2)) - (1 / 3) * Math.pow(Math.E, (-1) * (4 + Math.pow(realChromosomeY, 2)));
        return fx;
    }

    public double getFitnessMinimum(double maxF)
    {
        ffx= maxF- fx;
        return ffx;
    }

    public double getFitnessMaximum(double minF) // ako se racuna maksimum funkcije
    {
        ffx = fx - minF;
        return ffx;
    }

    public void calculateProbabilityOfChoice(double fitnessSum)
    {
        pi= ffx / fitnessSum;

    }

    public double getQi()
    {
        return qi;
    }

    @Override
    public String toString() {
        return "Individual [" + realChromosomeX+ ", " + realChromosomeY + "]";
    }

    public Individual copy() {
        Individual ind = new Individual();
        ind.chromosome_X = chromosome_X; //binarni kod broja slucajno izabranog u intervalu [Gd,Gg]
        ind.chromosome_Y = chromosome_Y;
        ind.realChromosomeX = realChromosomeX;
        ind.realChromosomeY = realChromosomeY;
        ind.qi = qi;
        ind.pi =  pi; //vjerovatnoca izbora jedinke
        ind.ffx = ffx;
        ind.fx = fx;
        return ind;
    }
}
