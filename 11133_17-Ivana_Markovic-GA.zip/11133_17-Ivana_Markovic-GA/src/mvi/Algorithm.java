package mvi;

import java.util.*;


import java.util.Random;
import java.util.stream.Collectors;

public class Algorithm {

    public static final double mutationProbability=0.05; //vjerovatnoca mutacije
    public static final double crossoverProbability=0.7; //vjerovatnoca rekombinacije
    public static final double populationSize=100;
    public double fitnessSum=0;
    public static final int MAX_GENERATIONS=200;

    public List<Individual> population;

    public Algorithm()
    {
        startAlgorithm();
    }
    public void startAlgorithm()
    {

        System.out.println("Initial population");
        initializePopulation();
        Scanner scanner=new Scanner(System.in);
        int global;
        population.forEach(System.out::println);
        System.out.println("Choose 1 if you want to calculate the minimum or 2 if you want to calculate the maximum");
        global=scanner.nextInt();
        for(int currentGeneration=0;currentGeneration<MAX_GENERATIONS;currentGeneration++)
        {
            boolean go = fitness(global);
            //boolean nastavak1=fitness(2);
            if(!go) {
                System.out.println("Best result is "+ population.get(0).realChromosomeX+" "+population.get(0).realChromosomeY);
                break;
            }

            /*if(!nastavak1) {
                System.out.println("Najbolji rezultat je "+ population.get(0).realChromosomeX+" "+population.get(0).realChromosomeY);
                break;
            }*/
            List<Individual> newPopulation= rouletteSelection();
            newPopulation=shuffleAndCrossover(newPopulation);
            newPopulation=mutation(newPopulation);

            System.out.println("Generation "+ currentGeneration);
            population.clear();
            newPopulation.stream().forEach(ind -> population.add(ind.copy()));

            newPopulation.clear();
            newPopulation=null;
        }
    }
    //kreiranje pocetne populacije
    public void initializePopulation()
    {
        population=new ArrayList<>();
        for(int i=0;i<populationSize;i++)
        {
            population.add(new Individual());
        }

    }

    //racnunajne kumulativne vjerovatnoce

    public void calculateCumulativeProbability()
    {
        population.forEach(i-> i.calculateProbabilityOfChoice(fitnessSum));

        for(int i=0;i<population.size();i++)
        {
            population.get(i).qi=0.0;

            for(int j=0;j<=i;j++)
            {
                //System.out.println(population.get(j).pi);
                population.get(i).qi+=population.get(j).pi;
            }
        }
    }

    //ocjenjivanje rezultata
    public Boolean fitness(int global)
    {
        fitnessSum = 0.0;
        List<Double> vrijednostiFunkcije = new ArrayList<>();

        for(int i=0;i<population.size();i++)
        {
            if (global==1) {
                double d=population.get(i).getFunctionValue();
                vrijednostiFunkcije.add(d); }
            if (global==2){
                double d=population.get(i).getMaxValue();
                vrijednostiFunkcije.add(d);
            }
        }

        Collections.sort(vrijednostiFunkcije, new Comparator<Double>() {
            @Override
            public int compare(Double o1, Double o2) {
                return o1>o2 ? 1 : o1<o2 ? -1 : 0;
            }
        });

        //vrijednostiFunkcije.stream().forEach(System.out::println);

        //za trazenje minimuma
        //System.out.println(vrijednostiFunkcije.size());
        double maksimalnaVr=vrijednostiFunkcije.get(vrijednostiFunkcije.size()-1);//za trazenje minimuma
        double minimalnaVr=vrijednostiFunkcije.get(0); //za trazenje maksimuma

        //lista za smjestanje ocjene dobrote pojedinacnih rezultata
        List<Double> fitnesi= new ArrayList<>();
        if (global==1) {
            population.forEach(i->{
                double vr=i.getFitnessMinimum(maksimalnaVr);
                fitnesi.add(vr);}); }
        if (global==2){
            population.forEach(i->{
                double vr=i.getFitnessMaximum(minimalnaVr);
                fitnesi.add(vr);}); }

        fitnesi.forEach(i->fitnessSum+=i);

        if(fitnessSum<=0)
        {
            System.out.println("The result is achieved!");
            return false;
        }

        Collections.sort(fitnesi, new Comparator<Double>() {
            @Override
            public int compare(Double o1, Double o2) {
                return o1>o2 ? 1 : o1<o2 ? -1 : 0;
            }
        });

        double najboljiFitnes=fitnesi.get(fitnesi.size()-1);


        for(int i=0;i<population.size();i++)
        {
            if(population.get(i).ffx==najboljiFitnes)
            {
                if (global==1) {
                System.out.println("The best adapted individual: "+population.get(i).realChromosomeX+" "+population.get(i).realChromosomeY);
                System.out.println("Minimum is: "+population.get(i).getFunctionValue()); }
                System.out.println("=================================================================");
                if (global==2) {
                System.out.println("The best adapted individual: "+population.get(i).realChromosomeY);
                System.out.println("Maximum is: "+population.get(i).getMaxValue()); }
                break;
            }


        }

        return true;
    }

    //ruletska selekcija

    public List<Individual> rouletteSelection()
    {
        calculateCumulativeProbability();
        List<Individual> newPopulation = new ArrayList<>();

        List<Individual> sortedList=population.stream().sorted(Comparator.comparing(Individual::getQi)).collect(Collectors.toList());

        double r;
        for (int i = 0; i < population.size(); i++)
        {
            r = new Random().nextDouble();
            if(r<population.get(0).getQi()) {
                newPopulation.add(population.get(0).copy());
            }
            for(int j=1;j<population.size();j++)
                if(population.get(j).qi>r && population.get(j-1).qi <= r)
                {
                    newPopulation.add(population.get(j).copy());
                    break;
                }
        }

        return newPopulation;
    }
    //mijesanje i rekombinacija
    public List<Individual> shuffleAndCrossover(List<Individual> population)
    {
        Collections.shuffle(population);
        population= crossover(population);
        return population;
    }

    //mutacija
    public List<Individual> mutation(List<Individual> population)
    {

        for(int i=0;i<population.size();i++)
        {
            if(new Random().nextDouble()< mutationProbability)
            {
                int br1=new Random().nextInt(Individual.chromosomeLength);
                if(population.get(i).chromosome_X[br1]==0)
                {
                    population.get(i).chromosome_X[br1]=1;
                }
                else
                    population.get(i).chromosome_X[br1]=0;

                int br2=new Random().nextInt(Individual.chromosomeLength);
                if(population.get(i).chromosome_Y[br2]==0)
                {
                    population.get(i).chromosome_Y[br2]=1;
                }
                else
                    population.get(i).chromosome_Y[br2]=0;
            }
        }

        return population;
    }

    //ukrstanje
    public List<Individual> crossover(List<Individual> population)
    {
        int parentsNumber=population.size()/2;

        for(int i=0;i<parentsNumber;i++)
        {
            int firstIndividualPosition=2*i;
            int secondIndividualPosition=2*i+1;

            if(new Random().nextDouble()< Algorithm.crossoverProbability)
            {
                for(int j=0;j<population.get(i).chromosome_X.length;j++)
                {
                    //rekombinacija x hromozoma
                    int temp= population.get(firstIndividualPosition).chromosome_X[j];
                    population.get(firstIndividualPosition).chromosome_X[j]=population.get(secondIndividualPosition).chromosome_X[j];
                    population.get(secondIndividualPosition).chromosome_X[j]=temp;

                    //rekombinacija y hromozoma
                    temp= population.get(firstIndividualPosition).chromosome_Y[j];
                    population.get(firstIndividualPosition).chromosome_Y[j]=population.get(secondIndividualPosition).chromosome_Y[j];
                    population.get(secondIndividualPosition).chromosome_Y[j]=temp;
                }

                population.get(firstIndividualPosition).realChromosomeX = population.get(firstIndividualPosition).getDoubleChromosomeX();
                population.get(secondIndividualPosition).realChromosomeX = population.get(secondIndividualPosition).getDoubleChromosomeX();
                population.get(firstIndividualPosition).realChromosomeY = population.get(firstIndividualPosition).getDoubleChromosomeY();
                population.get(secondIndividualPosition).realChromosomeY = population.get(secondIndividualPosition).getDoubleChromosomeY();
            }
        }

        return population;
    }
}