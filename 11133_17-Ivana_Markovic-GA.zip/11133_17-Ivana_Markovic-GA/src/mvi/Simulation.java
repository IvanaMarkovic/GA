package mvi;

public class Simulation {
    static int precision= 2;

    public static void main(String [] args)
    {
        Algorithm a=new Algorithm();

    }
}
